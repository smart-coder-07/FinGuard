package com.transaction.exception;

public class TransactionCustomException extends RuntimeException {

	public TransactionCustomException(String msg) {
		super(msg);
	}
	
	
}
