package com.user.exception;

public class UserCustomException extends RuntimeException {
	
	public UserCustomException(String msg) {
		super(msg);
	}

}
