package com.budget.exception;

public class BudgetCustomException extends RuntimeException {

	public BudgetCustomException(String msg) {
		super(msg);
	}
}
