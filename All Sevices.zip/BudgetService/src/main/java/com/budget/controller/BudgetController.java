package com.budget.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.budget.service.BudgetService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

import com.budget.model.Budget;

@RestController
@RequestMapping("/budget")
public class BudgetController {
	 
	@Autowired
	public BudgetService budgetservice;
	
	
	@GetMapping("/test")
	public ResponseEntity<String> test(){
		return new ResponseEntity<String>("Testing",HttpStatus.CREATED);
	}
	
	@PostMapping("/create")
	public ResponseEntity<Budget> setBudget(@RequestBody @Valid Budget budget, @RequestHeader("loggedInUser") int id){
		budget.setUserId(id);
		Budget budgetObj= budgetservice.setBudget(budget);
		return new ResponseEntity<Budget>(budgetObj,HttpStatus.CREATED);
		
	}

	@GetMapping("/getbybudgetid/{id}")
	public ResponseEntity<List<Budget>> getByBudgetid(@PathVariable @Valid int id){
		List<Budget> budget=budgetservice.getByBudgetid(id); 
		return new ResponseEntity<List<Budget>>(budget,HttpStatus.OK);
	}
	
	@GetMapping("/getbyuserid")
	public ResponseEntity<List<Budget>> getByuserId(@RequestHeader("loggedInUser") @Valid int uerid){
		List<Budget> budget=budgetservice.getByuserId(uerid); 
		return new ResponseEntity<List<Budget>> (budget,HttpStatus.OK);
	}
	
	@GetMapping("/getbybudgetcategory/{cat}")
	public ResponseEntity<List<Budget>> getBybcategory(@PathVariable @Valid String category){
		List<Budget> budget=budgetservice.getBybcategory(category);
		return new ResponseEntity<List<Budget>>(budget,HttpStatus.OK);
	}
	
	@GetMapping("/getcategory")
	public ResponseEntity<List<String>> updateByCategory(@RequestParam("userId") @Valid int userId){
		List<String> list=budgetservice.getCategory(userId); 
		return new ResponseEntity<List<String>>(list,HttpStatus.OK);
	}
	
	@DeleteMapping("/deletebybudgetid/{budgetid}")
	public ResponseEntity<String> deleteBybudgetid(@PathVariable @Valid int budgetid){
		String message= budgetservice.deleteBybudgetid(budgetid);
		return new ResponseEntity<String>(message,HttpStatus.CREATED);
		
	}
	
	@PutMapping("/updatebudget")
	public ResponseEntity<String> updateByCategory(@RequestParam("userId") @Valid int userId, @RequestParam("category") @Valid String category, @RequestParam("amount") @Valid double amount){
		budgetservice.updateByCategory(userId, category, amount); 
		return new ResponseEntity<String>("Updated",HttpStatus.OK);
	}

	
//	@PutMapping("/update")
//	public ResponseEntity<List<Budget>> updateByCategory(@RequestParam("userId") @Valid int userId, @RequestParam("category") @Valid String category, @RequestParam("amount") @Valid double amount){
//		List<Budget> budget=budgetservice.updateByCategory(userId, category, amount); 
//		return new ResponseEntity<List<Budget>>(budget,HttpStatus.OK);
//	}
}
