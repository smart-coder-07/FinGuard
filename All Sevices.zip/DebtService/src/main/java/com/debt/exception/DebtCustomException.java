package com.debt.exception;

public class DebtCustomException extends RuntimeException {
	
	public DebtCustomException(String msg) {
		super(msg);
	}

}