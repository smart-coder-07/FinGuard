package com.portfolio.exception;

public class PortfolioCustomException extends RuntimeException {
	
	public PortfolioCustomException(String msg) {
		super(msg);
	}

}
