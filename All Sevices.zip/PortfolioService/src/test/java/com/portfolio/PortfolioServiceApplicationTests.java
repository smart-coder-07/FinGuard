package com.portfolio;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
