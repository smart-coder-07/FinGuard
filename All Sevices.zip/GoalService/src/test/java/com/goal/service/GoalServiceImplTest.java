package com.goal.service;

import com.goal.exception.GoalsCustomException;
import com.goal.model.GoalModel;
import com.goal.model.User;
import com.goal.repository.GoalRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)  // Use Mockito for mocking dependencies
class GoalServiceTest {

    @Mock
    private GoalRepo goalRepository;  // Mock GoalRepo dependency

    @Mock
    private RestTemplate restTemplate; // Mock RestTemplate for external API calls

    @InjectMocks
    private GoalServiceImpl goalService; // The class under test (GoalServiceImpl)

    private GoalModel goal;
    private User user;

    @BeforeEach
    void setUp() {
        // Initialize mock goal and user objects
 

        goal = new GoalModel();
        goal.setGoalName("Buy Car");
        goal.setUserId(123);
        goal.setTargetAmount(20000);
        goal.setCurrentAmount(5000);
    }





  

    @Test
    void testUpdateProgress_Failure_GoalNotFound() {
        // Mock behavior to simulate goal not being found
        when(goalRepository.getByGoalName(123, "Buy Car")).thenReturn(null);

        // Expect an exception when trying to update progress on a non-existent goal
        assertThrows(GoalsCustomException.class, () -> goalService.updateProgress(123, "Buy Car", 5000),
                "Expected GoalsCustomException when goal is not found");
    }

    @Test
    void testGetByGoalName_Success() {
        // Mock goal repository to return an existing goal
        when(goalRepository.getByGoalName(123, "Buy Car")).thenReturn(goal);

        GoalModel foundGoal = goalService.getByGoalName(123, "Buy Car");

        assertNotNull(foundGoal, "Goal should not be null");
        assertEquals("Buy Car", foundGoal.getGoalName(), "Goal name should match");
    }



    @Test
    void testGetGoals_Success() {
        // Mock goal repository to return a list of goals for a user
        when(goalRepository.getGoals(123)).thenReturn(List.of(goal));

        List<GoalModel> goals = goalService.getGoals(123);

        assertNotNull(goals, "Goals list should not be null");
        assertFalse(goals.isEmpty(), "Goals list should not be empty");
        assertEquals("Buy Car", goals.get(0).getGoalName(), "Goal name should match");
    }

    @Test
    void testGetGoals_Failure_NoGoalsFound() {
        // Mock behavior to simulate no goals found for the user
        when(goalRepository.getGoals(123)).thenReturn(List.of());

        // Expect an exception when no goals are found
        assertThrows(GoalsCustomException.class, () -> goalService.getGoals(123),
                "Expected GoalsCustomException when no goals are found");
    }

    @Test
    void testDeleteGoal_Success() {
        // Mock goal repository to return an existing goal
        when(goalRepository.getByGoalName(123, "Buy Car")).thenReturn(goal);

        // Mock delete behavior of goalRepository
        doNothing().when(goalRepository).deleteById(anyInt());

        String message = goalService.deleteGoal(123, "Buy Car");

        assertEquals("Goal deleted", message, "Expected confirmation message on successful deletion");
    }

    @Test
    void testDeleteGoal_Failure_GoalNotFound() {
        // Mock behavior to simulate goal not being found
        when(goalRepository.getByGoalName(123, "Buy Car")).thenReturn(null);

        // Expect an exception when trying to delete a non-existent goal
        assertThrows(GoalsCustomException.class, () -> goalService.deleteGoal(123, "Buy Car"),
                "Expected GoalsCustomException when goal is not found");
    }
}