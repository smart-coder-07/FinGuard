package com.goal.service;

import java.util.List;

import com.goal.model.GoalSeviceModel;

public interface GoalServiceInterface {

	GoalSeviceModel createGoal(GoalSeviceModel obj);

	GoalSeviceModel updateProgress(int goalId, double amountSaved);

	List<GoalSeviceModel> getGoals(int userID, String goalName);

	GoalSeviceModel getGoal(int userID);

	GoalSeviceModel deleteGoal(int userId);

	List<GoalSeviceModel> getGoals();
}
