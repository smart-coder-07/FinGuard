package com.goal.exception;

public class GoalsCustomException extends RuntimeException{

	public GoalsCustomException(String msg) {
		super(msg);
	}
	

}
