package com.goal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.goal.exception.GoalsCustomException;
import com.goal.model.GoalModel;
import com.goal.model.GoalSeviceModel;
import com.goal.service.GoalServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/goals")
public class GoalServiceController {
	@Autowired
	GoalServiceImpl service;

	
	@GetMapping("/test")
	public ResponseEntity<String> test(){
		return new ResponseEntity<String>("Testing successfully", HttpStatus.OK);
	}
	
	@PostMapping("/create")
	public ResponseEntity<GoalModel> createGoal(@RequestBody @Valid GoalModel goal) {
		
		GoalModel goal1 = service.createGoal(goal);
		
		return new ResponseEntity<GoalModel>(goal1, HttpStatus.CREATED);
	}
		

	@DeleteMapping("/delete/{goalId}/{name}")
	@Valid
	public ResponseEntity<String> deleteGoal(@PathVariable int goalId, @PathVariable String name) {
		String goal21 = service.deleteGoal(goalId, name);
		return new ResponseEntity<String>(goal21, HttpStatus.CREATED);
	}
	
	@PutMapping("/updateProgress/{goalId}/{amountSaved}")
	@Valid
	public ResponseEntity<String> updateProgress(@PathVariable int goalId, @PathVariable String name, @PathVariable double amountSaved) {
		
		String goal223 = service.updateProgress(goalId, name, amountSaved);
		if(goal223==null) {
			throw new GoalsCustomException("Goal not Found"); 
		}
		return new ResponseEntity<String>(goal223, HttpStatus.CREATED);
		
			

	}
	
}



